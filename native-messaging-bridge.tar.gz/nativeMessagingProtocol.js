/**
 * Protocol wrapper for native messaging
 */

/**
 * @typedef {Object} WrappedMessage
 * @property {number} length - Original message length in bytes
 * @property {Object} message - The actual message
 */

/**
 * Wrap a message with protocol metadata
 * @param {Object} message - The message to wrap
 * @returns {WrappedMessage}
 */
function wrapMessage(message) {
  const originalJson = JSON.stringify(message)
  const originalLength = Buffer.from(originalJson).length

  return {
    length: originalLength,
    message: message
  }
}

/**
 * Unwrap a message from protocol
 * @param {WrappedMessage} wrapped - The wrapped message
 * @returns {Object|null} The original message or null if invalid
 */
function unwrapMessage(wrapped) {
  if (!wrapped || typeof wrapped !== 'object' || !wrapped.message || typeof wrapped.length !== 'number') {
    return null
  }

  const messageJson = JSON.stringify(wrapped.message)
  const actualLength = Buffer.from(messageJson).length

  if (actualLength !== wrapped.length) {
    return null
  }

  return wrapped.message
}

/**
 * Check if a message is wrapped
 * @param {*} message - The message to check
 * @returns {boolean}
 */
function isWrappedMessage(message) {
  return !!message && typeof message === 'object' && 'length' in message && 'message' in message
}

module.exports = {
  wrapMessage,
  unwrapMessage,
  isWrappedMessage
}
